OI Gateway- IMS#2451588 Installation Instructions
-----------------------oOo------------------------

Problems fixed:
================
OI Gateway consumes production license even if MQTT is not configured.


Software Requirements:
======================
CDP 2020R2 SP1, OI Gateway version 7.2.200


Contents of the HF
==================

Deliverables:                           File Version
-------------          			-------------
1.Gateway.dll                  		2023.505.4507.1
2.Readme-IMS2451588-HF			N/A
 
Installation Instructions:
==========================

a) Stop any OPC clients and undeploy any DiObjects if they are connected to OI Gateway locally or remotely.

b) Deactivate all instances of OI Gateway from the SMC. 

c) Close the SMC

d) Take a backup of the Gateway.dll at :
	"%SystemDrive%\Program Files\Wonderware\OI-Server\OI-Gateway\Bin" for 32-bit machines 
	"%SystemDrive%\Program Files (x86)\Wonderware\OI-Server\OI-Gateway\Bin" for 64-bit machines.

e) Copy the Gateway.dll from this HF package to :
	"%SystemDrive%\Program Files\Wonderware\OI-Server\OI-Gateway\Bin" for 32-bit machines 
	"%SystemDrive%\Program Files (x86)\Wonderware\OI-Server\OI-Gateway\Bin" for 64-bit machines.

f) Open SMC to continue with any configuration or to start the server

g) If there are multiple computers involved, please repeat steps a-f in each of those computer

-----------------------------------------------------------------------------------------------------------------------------

Other Brief Details:
====================
* Backup merely involves copying the files to a safe location.  Do not rename the files in the same location.
* Machine reboot is not required.


Copyright notice
================
� 2023 AVEVA Group Limited. All rights reserved.
The Schneider Electric industrial software business and AVEVA have merged to trade as AVEVA Group Limited, a UK listed company. The Schneider Electric and Life is On trademarks are owned by Schneider Electric and are being licensed to AVEVA by Schneider Electric.