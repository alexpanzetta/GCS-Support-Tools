Back and Run the stored procedure (aaGetUserKey)

1. Open  Microsoft SQL Server Management Studion.

2. Go to Database -> Runtime -> Programmability -> Stored Procedures -> aaGetUserKey, take backup of stored procedure(aaGetUserKey)

3. Copy the aaGetUserKey.sql to local disck.

4. Open this file (aaGetUserKey.sql) in Microsoft SQL Server Management Studion and Execute.



