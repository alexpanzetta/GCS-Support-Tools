OI Core hotfix IMS 2519933 Installation Instructions
---------------------------oOo--------------------------------

Fix: 
====
Fixed item activation/deactivation issues when performing window switching.

  
Software Requirements:
======================
Communication Drivers Pack 2023.1


Contents
========

Deliverables:          			File Version
-------------          			-------------
PlugInDDESL.dll				2023.706.4569.2
Readme-HotFix-IMS2519933.txt			N/A
 

Installation Instructions:
==========================
 
1) Deactivate all instances of OI Gateway, OI Servers,  DA Servers and FSGateway from the SMC.
   Undeploy all DiObjects via the IDE.

2) Take a backup of PlugInDDESL.dll located at folder location:
	"[root drive]:\Program Files\Common Files\ArchestrA" for 32-bit machines and 
	"[root drive]:\Program Files (x86)\Common Files\ArchestrA" for 64-bit machines.
   
3) Replace PlugInDDESL.dll with the one provided with this package at folder location:
	"[root drive]:\Program Files\Common Files\ArchestrA" for 32-bit machines and 
	"[root drive]:\Program Files (x86)\Common Files\ArchestrA" for 64-bit machines.

4) Activate appropriae OI Server instances from the SMC.
   Deploy all DiObjects via the IDE

Repeat steps from 1 to 4 on all the computer nodes where DiObjects or DA Servers are installed or deployed.

--------------------------------------------------

Other Brief Details:
====================
* Machine reboot is not required, not preferred

Copyright notice
================
� 2023 AVEVA Group Limited. All rights reserved.

