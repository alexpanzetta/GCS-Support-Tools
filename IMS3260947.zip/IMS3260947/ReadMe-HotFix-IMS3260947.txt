Aveva System Platform 2020 R2 SP1 P01 Hot Fix IMS3260947 Installation Instructions
==================================================================================

Issue
=====
Low priority alarms still get logged while it had been disabled in Alarm and event configuration

Software Requirements
=====================
Aveva System Platform 2020 R2 SP1 P01

----------------------------------------------------------------------------------------------------

Contents
========
* Ensure after extracting "HF-IMS3260947.exe" , the following hot fix deliverables are copied to the extracted location

        Default Extracted Location
        --------------------------
        Pre Vista OS - [Root Drive]:\Documents and Settings\All Users\Documents\AVEVA\HF-IMS3260947
        Vista and later OS - [Root Drive]:\Users\Public\Documents\AVEVA\HF-IMS3260947
        or [Root Drive]:\Users\Public\Public Documents\AVEVA\HF-IMS3260947

Deliverables                                       File Version        
------------                                       ------------        
NotificationDistributorRuntime.dll                 5250.1210.6731.1     
InstallHotfix.exe                                  2020.1202.3623.3     


Installation Instructions
=========================
*Note:
   If you create a new galaxy or restoring an existing galaxy, then you have to re-apply this Fix!

1. Execute "HF-IMS3260947.exe" to extract Hot Fix deliverables.
   Hot Fix deliverables will be copied to the location: "[Root Drive]:\Users\Public\Documents\AVEVA\HF-IMS3260947"

2. Ensure that there are 2 files at the location "[Root Drive]:\Users\Public\Documents\AVEVA\HF-IMS3260947"
   a.NotificationDistributorRuntime.dll
   b.InstallHotfix.exe

3. From SMC Platform Manager, stop the Platform. 

4. Close Wonderware Products Window Viewer,Object Viewer,SMC,ArchestrA IDE,InTouch OMI and Other LMX clients

5. Take a backup of "NotificationDistributorRuntime.dll" file located in the following locations and replace it with the one provided with the hotfix
   "[Root Drive]:\Program Files (x86)\ArchestrA\Framework\Bin"
   "[Root Drive]:\Program Files (x86)\ArchestrA\Framework\FileRepository\<GalaxyName>\Vendors\ArchestrA

6. If there are multiple galaxies created then repeat the step 5 for each of the galaxy folders.

7. From SMC Platform Manager, start Platform if not started. Set all the engines running on the Platform to ONSCAN.

8. Click on "Yes" button(s) to complete the installation. The Hotfix Manager tool will write the information of the Hot Fix to 
   "<Root Drive>:\ProgramData\AVEVA\Hotfixes\HFDB.xml"

Other brief details
===================
* The fix should be applied on all the platforms preferably on GR node first.

* Backup merely involves copying the files to another location. Do not rename the files in the same location.

* Machine does not have to be rebooted.

* On 32-bit OS the Program Files path will be "[RootDrive:]\Program Files\"

* You can view HotFix information installed on the machine by executing HotFixViewer.exe located at:
   <Root Drive>:\Program Files (x86)\AVEVA\HotfixViewer

Copyright notice
================
� 2024 AVEVA Group Limited and its subsidiaries. All rights reserved.
Refer to: https://sw.aveva.com/legal/trademarks