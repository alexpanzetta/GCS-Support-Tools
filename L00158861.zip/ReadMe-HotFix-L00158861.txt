Wonderware System Platform 2017 UPDATE 3 SP1 P01 Hot Fix L00158861 Installation Instructions
====================================================================================

Issue
=====
In case aagr.exe is restarted it takes up to 10 min before the IDE/ SMC is started.

Software Requirements
=====================
Wonderware System Platform 2017 UPDATE 3 SP1 P01

----------------------------------------------------------------------------------------------------

Contents
========
* Ensure after extracting "HF-L00158861.exe" , the following hot fix deliverables are copied to the extracted location

      Default Extracted Location
      --------------------------
      Pre Vista OS - [Root Drive]:\Documents and Settings\All Users\Documents\Schneider Electric\HF-L00158861
      Vista and later OS - [Root Drive]:\Users\Public\Documents\Schneider Electric\HF-L00158861
      or [Root Drive]:\Users\Public\Public Documents\Schneider Electric\HF-L00158861

Deliverables                                       File Version        
------------                                       ------------
aaGR.exe                                           5593.55.8990.1
WWPackageServer.dll                                5593.377.8990.1
InstallHotfix.exe                                  2018.1025.2854.1

Installation Instructions
=========================

1. Execute "HF-L00158861.exe" to extract Hot Fix deliverables.
   Hot Fix deliverables will be copied to the location: "[Root Drive]:\Users\Public\Documents\Schneider Electric\HF-L00158861"

2. Ensure that there are 3 files at the location "[Root Drive]:\Users\Public\Documents\Schneider Electric\HF-L00158861"
   a.aaGR.exe
   b.WWPackageServer.dll
   c.InstallHotfix.exe

3. Close Wonderware products ArchestrA IDE, SMC, WindowMaker and WindowViewer if they are running.

4. From SMC Platform Manager, stop GR Platform.

5. Stop ArchestrA GalaxyRepository service and Watchdog service by executing the following commands Command Prompt(Run as Administrator).
       Net Stop watchdog_service
       sc config aaGR start= disabled
       Net Stop aaGR

6. Take a backup of the "WWPackageServer.dll" located at "<RootDrive>:\Program Files\Common Files\ArchestrA\Framework\Bin" folder.
   Replace this with the one provided with hot fix.

7. Take a backup of the "aaGR.exe" located at "<RootDrive>:\Program Files\ArchestrA\Framework\Bin" folder.
   Replace this with the one provided with hot fix.

8. Start ArchestrA GalaxyRepository service and Watchdog service by executing the following commands from Command Prompt(Run as Administrator).
      sc config aaGR start= auto
      Net Start aaGR
      Net Start watchdog_service

9. From SMC Platform Manager, start GR Platform if not started. Set all the engines running on GR platform to ON SCAN.

10. Start ArchestrA IDE and connect to galaxy.


Other brief details:
=====================

*  The fix should be applied to GR Node only.

*  On 64-bit OS the Program Files path will be "[RootDrive]:\Program Files (x86)\"

*  Backup merely involves copying the files to a safe location. Do not rename the files in the same location.

*  Machine reboot is not required.

Copyright notice:
=================
� 2018 AVEVA Group Plc. All rights reserved.
