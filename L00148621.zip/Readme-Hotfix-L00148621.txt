		Wonderware Historian 11.6 SP1 P02 Hotfix for L00148621 - Slow Metadata server performance due to many tag versions
    		-----------------------------------------------------oOo----------------------------------------------------------

Resolved Issues:
================
SR10918100 - Historian - 11.6 SP1 P02 : Warning - Main Storage Failed to detect known tagids in Metadata Server, last error = 1460

Solution:

Changeset: 417325
-----------------------------------------------------------------

Software Requirements:
======================
System Platform 2014R2SP1P02


Contents
=======

Deliverables included in folders:	File Version
================================	============
Win32 (For client side - AppEngine):
	aahClient.dll			2014.1210.9910.1
	aahClientCommon.dll		2014.1210.9910.1
      
      (For Historian)
	aahMetadataServer.exe		2014.1210.9910.1

X64 (For Historian):
	aahMetadataServer.exe		2014.1210.9910.1


-----------------------------------------------------------------


Installation Instructions on Wonderware Application Server Platform node:
=========================================================================


BACKUP:
------------

1. Make a backup of the files "aahClient.dll" and "aahClientCommon.dll" from the following installation path
     On 32-bit OS "[RootDrive]:\Program Files\Common Files\ArchestrA"
     On 64-bit OS "[RootDrive]:\Program Files (x86)\Common Files\ArchestrA"


REPLACING DLLs:
------------------------------------------------------------------------------

1. From SMC Platform Manager, stop the Platform and all the engines running under it. 
   This step may take sometime.

2. This step may not be necessary. If issue with Step 1 encountered, please do the following:
   Stop ArchestrA Bootstrap service by executing the following commands from Start->Run
     sc config aaBootstrap start= disabled
     Net Stop aaBootstrap

3. Copy files "aahClient.dll" and "aahClientCommon.dll" to the following location
     On 32-bit OS "[RootDrive]:\Program Files\Common Files\ArchestrA"
     On 64-bit OS "[RootDrive]:\Program Files (x86)\Common Files\ArchestrA"

4. If Step 2 was not performed procede to step 5, otherwise perform the following:
     Start ArchestrA Bootstrap service by executing the following commands from Start->Run
	sc config aaBootstrap start= auto
	Net Start aaBootstrap

5. From SMC Platform Manager, start Platform if not started. Set all the engines running on the 
   Platform to ON SCAN.

6. Repeat the above steps for all the Platforms that have engines historizing data.



Installation Instructions on Wonderware Historian node:
=======================================================

BACKUP:
------------

1. Make a backup of the files "aahMetadataServer.exe" from the following installation path
     On 32-bit OS "[RootDrive]:\Program Files\Common Files\ArchestrA"
     On 64-bit OS "[RootDrive]:\Program Files (x86)\Common Files\ArchestrA"


REPLACING EXEs:
------------------------------------------------------------------------------

1. From Historian Management Console:
   Status, All Tasks, Shutdown (and disable) Historian

2. Replcace "aahMetadataServer.exe" at the following installation path
     On 32-bit OS "[RootDrive]:\Program Files\Common Files\ArchestrA"
     On 64-bit OS "[RootDrive]:\Program Files (x86)\Common Files\ArchestrA"

3. Restart Historian


Other brief details:
====================
*  Backup merely involves copying the files to a safe location. Do not rename the files in the same location.
*  Machine reboot is not required.
